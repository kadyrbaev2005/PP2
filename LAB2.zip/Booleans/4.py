x = "Hello"
y = 15

print(bool(x))
print(bool(y))