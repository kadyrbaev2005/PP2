a = 200
b = 33

if b > a:
  print("b is greater than a")
else:
  print("b is not greater than a")