bool("abc")
bool(123)
bool(["apple", "cherry", "banana"])