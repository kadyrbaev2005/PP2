a = 33
b = 200

if b > a:
  pass