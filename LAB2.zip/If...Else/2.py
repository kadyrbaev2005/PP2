a = 33
b = 200
if b > a:
print("b is greater than a") # you will get an error