a = 2
b = 330
print("A") if a > b else print("B")