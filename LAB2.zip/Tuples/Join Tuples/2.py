fruits = ("apple", "banana", "cherry")
mytuple = fruits * 2

print(mytuple)