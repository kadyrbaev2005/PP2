thistuple = ("apple", "banana", "cherry")
print(thistuple[1])