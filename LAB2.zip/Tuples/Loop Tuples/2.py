thistuple = ("apple", "banana", "cherry")
for i in range(len(thistuple)):
  print(thistuple[i])