for x in thisdict:
  print(thisdict[x])