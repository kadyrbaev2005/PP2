for x in thisdict:
  print(x)