for x in thisdict.keys():
  print(x)