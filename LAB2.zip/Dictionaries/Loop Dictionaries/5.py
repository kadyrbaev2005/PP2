for x, y in thisdict.items():
  print(x, y)