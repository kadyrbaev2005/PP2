for x in thisdict.values():
  print(x)