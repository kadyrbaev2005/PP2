thisdict = dict(name = "John", age = 36, country = "Norway")
print(thisdict)