i = 1
while i < 6:
  print(i)
  i += 1