i = 1
while i < 6:
  print(i)
  if i == 3:
    break
  i += 1