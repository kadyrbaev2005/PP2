thislist = ["apple", "banana", "cherry"]
del thislist