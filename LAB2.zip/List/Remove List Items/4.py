thislist = ["apple", "banana", "cherry"]
thislist.pop()
print(thislist)