thislist = ["apple", "banana", "cherry"]
thislist.clear()
print(thislist)