thislist = ["apple", "banana", "cherry"]
for x in thislist:
  print(x)