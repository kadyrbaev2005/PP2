thislist = ["apple", "banana", "cherry"]
thislist[1:3] = ["watermelon"]
print(thislist)