thislist = ["apple", "banana", "cherry"]
print(len(thislist))