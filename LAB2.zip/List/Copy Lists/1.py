thislist = ["apple", "banana", "cherry"]
mylist = thislist.copy()
print(mylist)