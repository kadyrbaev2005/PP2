for x in range(2, 6):
  print(x)