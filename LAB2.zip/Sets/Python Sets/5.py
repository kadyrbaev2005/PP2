thisset = {"apple", "banana", "cherry"}

print(len(thisset))