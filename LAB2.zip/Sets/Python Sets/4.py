thisset = {"apple", "banana", "cherry", False, True, 0}

print(thisset)