thisset = {"apple", "banana", "cherry", True, 1, 2}

print(thisset)