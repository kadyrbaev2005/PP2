thisset = {"apple", "banana", "cherry"}

del thisset

print(thisset)